import cirpy
import openpyxl
import warnings

import pandas as pd
import numpy as np

from tqdm import tqdm

pd.set_option('mode.chained_assignment', None)
warnings.filterwarnings("ignore")

data = pd.read_excel('tg416_1.xlsx')

tqdm.pandas()
data['SMILES'] = data.CasRN.progress_apply(lambda x: cirpy.resolve(x, 'smiles'))

data.to_excel('tg416_1_smiles.xlsx', header = True, index = False)